# MySQL 爬虫练习项目

这个项目用于练习 Python 连接 MySQL、封装数据库操作、爬取网页数据并写入数据库。

## 项目内容

- `mysql_helper/mysql_helper.py`：封装 MySQL 查询和写入操作
- `mysql_helper/test_connection.py`：测试 Python 连接 MySQL
- `mysql_helper/test_helper.py`：练习学生表增删改查
- `mysql_helper/fetch_baidu.py`：爬取百度热搜 Top 10 并写入数据库
- `mysql_helper/fetch_douban.py`：爬取豆瓣电影 Top 100 并写入数据库
- `mysql_helper/export_results.py`：导出数据库表到 `results/`
- `schema.sql`：数据库建表语句
- `results/`：已导出的运行结果

## 环境准备

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## 数据库配置

先执行 `schema.sql` 创建数据库和数据表。

复制配置模板：

```bash
cp .env.example .env
```

然后在 `.env` 中填写本机 MySQL 密码：

```env
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=your_mysql_password
MYSQL_DATABASE=internship
```

`.env` 不会上传到 GitHub。

## 运行方式

```bash
python mysql_helper/test_connection.py
python mysql_helper/test_helper.py
python mysql_helper/fetch_baidu.py
python mysql_helper/fetch_douban.py
python mysql_helper/export_results.py
```

## 已导出结果

本次导出的结果在 `results/`：

- `student.csv`：4 条学生数据
- `hot_search.csv`：10 条百度热搜数据
- `movie.csv`：100 条豆瓣电影数据
- `export_summary.txt`：导出时间和行数汇总
