import pymysql
from pymysql.cursors import DictCursor


class MySqlHelper:
    def __init__(self, host, user, password, database,
                 port=3306, charset='utf8mb4'):
        self._config = dict(
            host=host,
            user=user,
            password=password,
            database=database,
            port=port,
            charset=charset,
            cursorclass=DictCursor,
            autocommit=False,
        )
        self._conn = pymysql.connect(**self._config)

    def execute(self, sql, params=None):
        self._conn.ping(reconnect=True)
        with self._conn.cursor() as cursor:
            affected = cursor.execute(sql, params)
            self._conn.commit()
            return affected

    def query_one(self, sql, params=None):
        self._conn.ping(reconnect=True)
        with self._conn.cursor() as cursor:
            cursor.execute(sql, params)
            return cursor.fetchone()

    def query_all(self, sql, params=None):
        self._conn.ping(reconnect=True)
        with self._conn.cursor() as cursor:
            cursor.execute(sql, params)
            return cursor.fetchall()

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None
