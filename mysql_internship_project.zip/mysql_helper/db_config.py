import os
from pathlib import Path


def load_env_file():
    env_path = Path(__file__).resolve().parent.parent / '.env'
    if not env_path.exists():
        return

    for line in env_path.read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        key, value = line.split('=', 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


def get_db_config():
    load_env_file()
    password = os.environ.get('MYSQL_PASSWORD')
    if not password:
        raise RuntimeError('请先设置 MYSQL_PASSWORD 环境变量')

    return {
        'host': os.environ.get('MYSQL_HOST', 'localhost'),
        'user': os.environ.get('MYSQL_USER', 'root'),
        'password': password,
        'database': os.environ.get('MYSQL_DATABASE', 'internship'),
        'port': int(os.environ.get('MYSQL_PORT', '3306')),
        'charset': 'utf8mb4',
    }
