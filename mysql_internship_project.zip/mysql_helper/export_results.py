import csv
from datetime import datetime
from pathlib import Path

from db_config import get_db_config
from mysql_helper import MySqlHelper


TABLES = ('student', 'hot_search', 'movie')
RESULTS_DIR = Path(__file__).resolve().parent.parent / 'results'


def export_table(db, table_name):
    columns = db.query_all(f"SHOW COLUMNS FROM `{table_name}`")
    fieldnames = [column['Field'] for column in columns]
    rows = db.query_all(f"SELECT * FROM `{table_name}`")

    output_path = RESULTS_DIR / f'{table_name}.csv'
    with output_path.open('w', newline='', encoding='utf-8-sig') as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    return output_path, len(rows)


def main():
    RESULTS_DIR.mkdir(exist_ok=True)
    db = MySqlHelper(**get_db_config())
    summary = [f"导出时间：{datetime.now()}"]

    try:
        for table_name in TABLES:
            output_path, row_count = export_table(db, table_name)
            summary.append(f"{table_name}: {row_count} 行 -> {output_path.name}")
            print(f"{table_name}: 导出 {row_count} 行")
    finally:
        db.close()

    summary_path = RESULTS_DIR / 'export_summary.txt'
    summary_path.write_text('\n'.join(summary) + '\n', encoding='utf-8')
    print(f"导出完成：{RESULTS_DIR}")


if __name__ == '__main__':
    main()
