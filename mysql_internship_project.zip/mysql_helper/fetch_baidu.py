import requests
from bs4 import BeautifulSoup
from datetime import datetime

from db_config import get_db_config
from mysql_helper import MySqlHelper

URL = 'https://top.baidu.com/board?tab=realtime'

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/120.0.0.0 Safari/537.36'
    )
}

print("正在抓取百度热搜...")
response = requests.get(URL, headers=HEADERS, timeout=10)
response.raise_for_status()
html = response.text

soup = BeautifulSoup(html, 'lxml')
items = soup.find_all('div', class_='category-wrap_iQLoo')
print(f"页面上共有 {len(items)} 条热搜，我们存前 10 条到数据库\n")

fetched_at = datetime.now()

db = MySqlHelper(**get_db_config())

INSERT_SQL = """
    INSERT INTO hot_search (rank_no, title, description, hot_index, fetched_at)
    VALUES (%s, %s, %s, %s, %s)
"""

inserted = 0
for rank, item in enumerate(items[:10], start=1):
    title_elem = item.find('div', class_='c-single-text-ellipsis')
    title = title_elem.get_text(strip=True) if title_elem else ''

    desc_elem = item.find('div', class_='hot-desc_1m_jR')
    if desc_elem:
        for a in desc_elem.find_all('a'):
            a.extract()
        desc = desc_elem.get_text(strip=True)
    else:
        desc = ''

    index_elem = item.find('div', class_='hot-index_1Bl1a')
    hot_index_str = index_elem.get_text(strip=True) if index_elem else '0'
    hot_index = int(hot_index_str)

    affected = db.execute(INSERT_SQL, (rank, title, desc, hot_index, fetched_at))
    inserted += affected
    print(f"#{rank} {title[:30]} 写入 {affected} 行")

print(f"\n共写入 {inserted} 条记录，时间戳：{fetched_at}")

db.close()
