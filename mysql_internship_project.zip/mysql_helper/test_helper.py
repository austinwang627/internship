from db_config import get_db_config
from mysql_helper import MySqlHelper

db = MySqlHelper(**get_db_config())

print("--- 1. 查所有学生 ---")
all_students = db.query_all("SELECT * FROM student")
for student in all_students:
    print(student)

print("\n--- 2. 查 id=1 的学生 ---")
one_student = db.query_one("SELECT * FROM student WHERE id = %s", (1,))
print(one_student)

print("\n--- 3. 插入 ---")
affected = db.execute(
    "INSERT INTO student (name, height) VALUES (%s, %s)",
    ('测试', 170.00)
)
print(f"插入了 {affected} 行")

print("\n--- 4. 更新 ---")
affected = db.execute(
    "UPDATE student SET height = %s WHERE name = %s",
    (175.00, '测试')
)
print(f"更新了 {affected} 行")

print("\n--- 5. 删除 ---")
affected = db.execute(
    "DELETE FROM student WHERE name = %s",
    ('测试',)
)
print(f"删除了 {affected} 行")

print("\n--- 6. 确认最终状态 ---")
for student in db.query_all("SELECT * FROM student"):
    print(student)

db.close()
