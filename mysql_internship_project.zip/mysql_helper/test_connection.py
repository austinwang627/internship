import pymysql

from db_config import get_db_config


conn = pymysql.connect(**get_db_config())

cursor = conn.cursor()

cursor.execute("SELECT * FROM student")

rows = cursor.fetchall()

for row in rows:
    print(row)

cursor.close()
conn.close()
