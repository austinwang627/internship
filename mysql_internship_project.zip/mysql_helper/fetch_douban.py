import re
import time
import requests
from bs4 import BeautifulSoup
from datetime import datetime

from db_config import get_db_config
from mysql_helper import MySqlHelper

BASE_URL = 'https://movie.douban.com/top250?start={}'
PAGES = [0, 25, 50, 75]
SLEEP_SECONDS = 2

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/120.0.0.0 Safari/537.36'
    ),
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
}


def parse_one_movie(item):
    rank_no = int(item.select_one('div.pic em').get_text(strip=True))
    poster_url = item.select_one('div.pic img').get('src', '')

    title_spans = item.select('div.hd a span.title')
    title = title_spans[0].get_text(strip=True) if title_spans else ''
    original_title = ''
    if len(title_spans) >= 2:
        original_title = title_spans[1].get_text(strip=True).lstrip('/').strip()

    bd_p = item.select_one('div.bd p')
    bd_text = bd_p.get_text(separator='\n', strip=True)
    lines = [line.strip() for line in bd_text.split('\n') if line.strip()]
    line1 = lines[0] if len(lines) >= 1 else ''
    line2 = lines[1] if len(lines) >= 2 else ''

    director, cast_main = '', ''
    if '导演:' in line1:
        after_director = line1.split('导演:', 1)[1]
        if '主演:' in after_director:
            director, cast_main = after_director.split('主演:', 1)
        else:
            director = after_director
        director = director.strip()
        cast_main = cast_main.strip()

    parts = [p.strip() for p in line2.split('/')]
    year = int(parts[0]) if len(parts) >= 1 and parts[0].isdigit() else None
    country = parts[1] if len(parts) >= 2 else ''
    genre = parts[2] if len(parts) >= 3 else ''

    rating_elem = item.select_one('span.rating_num')
    rating = float(rating_elem.get_text(strip=True)) if rating_elem else None

    item_text = item.get_text(separator=' ', strip=True)
    all_nums = [int(n) for n in re.findall(r'\d+', item_text)]
    votes = max(all_nums) if all_nums else None

    quote_elem = (
        item.select_one('p.quote span.inq')
        or item.select_one('span.inq')
        or item.select_one('p.quote')
    )
    quote = quote_elem.get_text(strip=True) if quote_elem else ''

    return {
        'rank_no': rank_no,
        'title': title,
        'original_title': original_title,
        'year': year,
        'director': director,
        'cast_main': cast_main,
        'country': country,
        'genre': genre,
        'rating': rating,
        'votes': votes,
        'quote': quote,
        'poster_url': poster_url,
    }


def fetch_page(start):
    url = BASE_URL.format(start)
    print(f"  抓取 start={start} ...", end=' ')
    response = requests.get(url, headers=HEADERS, timeout=10)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'lxml')
    items = soup.select('ol.grid_view > li')
    print(f"得到 {len(items)} 部")
    return [parse_one_movie(item) for item in items]


def main():
    print("开始抓取豆瓣 Top 100（4 页）...\n")
    all_movies = []
    for i, start in enumerate(PAGES):
        movies = fetch_page(start)
        all_movies.extend(movies)
        if i < len(PAGES) - 1:
            print(f"  休眠 {SLEEP_SECONDS} 秒...")
            time.sleep(SLEEP_SECONDS)

    print(f"\n抓取完成，共 {len(all_movies)} 部电影\n")

    fetched_at = datetime.now()
    db = MySqlHelper(**get_db_config())

    INSERT_SQL = """
        INSERT INTO movie (
            rank_no, title, original_title, year,
            director, cast_main, country, genre,
            rating, votes, quote, poster_url, fetched_at
        ) VALUES (
            %s, %s, %s, %s,
            %s, %s, %s, %s,
            %s, %s, %s, %s, %s
        )
    """

    print(f"开始写入数据库（时间戳：{fetched_at}）...")
    inserted = 0
    for m in all_movies:
        affected = db.execute(INSERT_SQL, (
            m['rank_no'], m['title'], m['original_title'], m['year'],
            m['director'], m['cast_main'], m['country'], m['genre'],
            m['rating'], m['votes'], m['quote'], m['poster_url'], fetched_at,
        ))
        inserted += affected
        if m['rank_no'] % 10 == 0:
            print(f"  已写入 #{m['rank_no']:>3} {m['title']}")

    db.close()
    print(f"\n{inserted} 部电影已入库")


if __name__ == '__main__':
    main()
