CREATE DATABASE IF NOT EXISTS internship DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE internship;

CREATE TABLE IF NOT EXISTS student (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    height DECIMAL(5, 2)
) DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS hot_search (
    id INT PRIMARY KEY AUTO_INCREMENT,
    rank_no INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    hot_index INT,
    fetched_at DATETIME
) DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS movie (
    id INT PRIMARY KEY AUTO_INCREMENT,
    rank_no INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    original_title VARCHAR(255),
    year INT,
    director VARCHAR(255),
    cast_main TEXT,
    country VARCHAR(255),
    genre VARCHAR(255),
    rating DECIMAL(3, 1),
    votes INT,
    quote VARCHAR(255),
    poster_url TEXT,
    fetched_at DATETIME
) DEFAULT CHARSET=utf8mb4;
