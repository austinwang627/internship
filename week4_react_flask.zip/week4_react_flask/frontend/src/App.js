import { useState } from "react";

function App() {
  const [firstValue, setFirstValue] = useState("");
  const [bodyValue, setBodyValue] = useState("");
  const [paramValue, setParamValue] = useState("");
  const [getResult, setGetResult] = useState("");
  const [postResult, setPostResult] = useState("");

  async function sendGetRequest() {
    const response = await fetch(
      `/api/echo?value=${encodeURIComponent(firstValue)}`,
    );
    setGetResult(await response.text());
  }

  async function sendPostRequest() {
    const response = await fetch(
      `/api/body-param?param=${encodeURIComponent(paramValue)}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ body: bodyValue }),
      },
    );
    setPostResult(await response.text());
  }

  return (
    <div className="app">
      <input
        value={firstValue}
        onChange={(event) => setFirstValue(event.target.value)}
        placeholder="第一个输入框"
      />
      <input
        value={bodyValue}
        onChange={(event) => setBodyValue(event.target.value)}
        placeholder="第二个输入框"
      />
      <input
        value={paramValue}
        onChange={(event) => setParamValue(event.target.value)}
        placeholder="第三个输入框"
      />

      <button onClick={sendGetRequest}>按钮1</button>
      <button onClick={sendPostRequest}>按钮2</button>

      <p>{getResult}</p>
      <p>{postResult}</p>
    </div>
  );
}

export default App;
