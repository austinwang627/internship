import socket

from flask import Flask, request

app = Flask(__name__)


@app.get("/api/echo")
def echo():
    value = request.args.get("value", "")
    return f"参数是{value}"


@app.post("/api/body-param")
def body_param():
    data = request.get_json(silent=True) or {}
    body_value = data.get("body", "")
    param_value = request.args.get("param", "")
    return f"body中的参数是{body_value}，param中的参数是{param_value}"


if __name__ == "__main__":
    socket.getfqdn = lambda name="": name or "localhost"
    app.run(host="127.0.0.1", port=5001, debug=False)
