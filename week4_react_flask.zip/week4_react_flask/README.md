# 第四周作业

这个项目是一个简单的 React + Flask 前后端联调练习。

页面里有三个输入框和两个按钮：

- 点击第一个按钮，会把第一个输入框的内容作为参数发给后端。
- 点击第二个按钮，会把第二个输入框作为 body，第三个输入框作为 param 发给后端。

## 后端运行

```sh
cd week4_react_flask/backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

## 前端运行

```sh
cd week4_react_flask/frontend
npm install
npm start
```

浏览器打开：

`http://localhost:3000`
